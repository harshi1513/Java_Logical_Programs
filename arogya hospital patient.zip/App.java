package com.bitlabs.ArogyaHospital;
import java.util.Scanner;
public class App {

    public static void main(String [] args) {
    DaoInterface dao=new DaoImpl();
    Patient p=new Patient();
    
    p.setId(105);
    p.setAge(35);
    p.setName("akhil");
    p.setGender("male");
    p.setCity("vijayawada");
    p.setAddress("96-47,vijayawada");
    p.setGuardian_name("lavanya");
    p.setGuardian_address("48-236");
    p.setDateOfAdmission("1991/12/14");
    p.setAadhar_Card_number(2569874);
    p.setContact_number(6985472);
    p.setGuardian_contactNumber(7975101);
    Scanner sc=new Scanner(System.in);
    System.out.println("choose the required option");
    System.out.println("1.patient registration 2.view all 3.search patient by id 4.delete patient by id 5.search patient by city 6.search patient by age group");
    int n=sc.nextInt();
    switch(n)
    {
    case 1:
    	if(n==1)
    		dao.patientRegistration(p);	
    	break;
    case 2:
    	if(n==2)
    		dao.viewAllPatient();
    		break;
    case 3:
    	if(n==3)
    		dao.searchPatientById(103);
    		break;
    case 4:
    	if(n==4)
    		dao.deletePatientById(105);
    		break;
    case 5:
    	if(n==5)
    		dao.searchPatientByCity("vijayawada");
    		break;
    case 6:
    	if(n==6)
    		dao.searchPatientByAgeGroup(18,58);
    		break;
    }
    sc.close();
    
    
}

}